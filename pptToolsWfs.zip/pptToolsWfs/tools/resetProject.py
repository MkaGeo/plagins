# -*- coding: utf-8 -*-
from qgis.core import QgsProject, QgsExpressionContextUtils, QgsFeatureRequest, \
    QgsAuthMethodConfig, QgsApplication
from PyQt5.QtCore import QSettings
from qgis.gui import QgsMapToolIdentifyFeature
from PyQt5.QtWidgets import QWidget, QLineEdit, QComboBox, QRadioButton, QTextEdit, QDialogButtonBox
from .baseTool import BaseTool


class ResetProjectTool(BaseTool):
    """"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self):
        for var in self.project_variables:
            QgsExpressionContextUtils.setProjectVariable(
                QgsProject.instance(), var, ''
            )
        for layer_name in self.filtered_layers:
            try:
                layer = QgsProject.instance().mapLayersByName(layer_name)[0]
                layer.setSubsetString('False')
            except:
                self.log("Не удалось сбросить фильтр для слоя {}".format(layer_name))
        
        #фильтр слов по номеру заявки
        filter_string = "oasi_documentid = ''"
        for layer_name in self.filtered_layers:
            try:
                layer = QgsProject.instance().mapLayersByName(layer_name)[0]
                layer.setSubsetString(filter_string)
            except:
                self.log("Не удалось установить фильтр для слоя {}".format(layer_name))

        self.switchActions()