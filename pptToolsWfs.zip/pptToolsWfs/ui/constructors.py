import os

from PyQt5 import uic
from PyQt5.QtWidgets import QDialog


importLayers, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'importLayersDlg.ui'))
exportLayers, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'exportLayersDlg.ui'))
loadDb2, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'loadDb2Dlg.ui'))
searchProject, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'searchProjectDialog.ui'))
# setProjectUi, _ = uic.loadUiType(os.path.join(
#     os.path.dirname(__file__), 'setProjectDlg.ui'))


class ImportApgrDlg(QDialog, importLayers):
    def __init__(self, parent=None):
        """Конструктор диалогового окна импорта слоев"""
        super(ImportApgrDlg, self).__init__(parent)
        self.setupUi(self)

class ExportApgrDlg(QDialog, exportLayers):
    def __init__(self, parent=None):
        """Конструктор диалогового окна экспорта слоев"""
        super(ExportApgrDlg, self).__init__(parent)
        self.setupUi(self)

class LoadDb2Dlg(QDialog, loadDb2):
    def __init__(self, parent=None):
        """Конструктор диалогового окна экспорта слоев"""
        super(LoadDb2Dlg, self).__init__(parent)
        self.setupUi(self)

class SearchProjectDlg(QDialog, searchProject):
    def __init__(self, parent=None):
        """Конструктор диалогового окна экспорта слоев"""
        super().__init__(parent)
        self.setupUi(self)

# class SetProjectDlg(QDialog, setProjectUi):
#     def __init__(self, parent=None):
#         """Конструктор формы настройки проекта"""
#         super(SetProjectDlg, self).__init__(parent)
#         self.setupUi(self)