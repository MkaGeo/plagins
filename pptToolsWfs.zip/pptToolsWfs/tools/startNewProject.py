# -*- coding: utf-8 -*-

from qgis.core import QgsProject, QgsExpressionContextUtils
from .baseTool import BaseTool


class StartNewProject(BaseTool):
    projectVariables = [
        'documentId',
        'project_name',
        'numberOrder',
        'numberOrder',
        'namePPT',
        'address'
    ]
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self):
        """Сброс фильтров слоев и переменных проекта"""
        for layerName in self.filtered_layers:
            layer = QgsProject.instance().mapLayersByName(layerName)[0]
            layer.setSubsetString("")

        for projVar in self.projectVariables:
            QgsExpressionContextUtils.setProjectVariable(
                QgsProject.instance(),
                projVar, ''
            )
        
        self.switchActions()
