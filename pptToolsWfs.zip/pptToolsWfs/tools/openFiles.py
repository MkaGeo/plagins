# -*- coding: utf-8 -*-

from psycopg2 import sql
import ntpath
from PyQt5 import QtWidgets
from qgis.core import QgsVectorLayer, QgsProject, QgsCoordinateReferenceSystem,\
    QgsExpressionContextUtils, QgsFeatureRequest, QgsEditorWidgetSetup
from .baseTool import BaseTool

class OpenFiles(BaseTool):
    """Инструмент для загрузки mid/mif файлов
    в проект QGIS
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dict_fields = {}


    def run(self):
        self.iface.mainWindow().blockSignals(True)
        selected_files = self.select_files() # открывает окно выбора файлов
        
        if selected_files:
            # создается группа слоев
            target_group = self.create_group()
            self.dict_fields = self.read_dic_fields()

        for file_name in selected_files:
            # имя слоя формируется из имени файла
            title = ntpath.basename(file_name).split('.')[0]
            new_layer = QgsVectorLayer(
                file_name, title, 'ogr'
            )
            self.log('Открывается файл {}'.format(file_name), 0, False)
            new_layer.setProviderEncoding('windows-1251') # кодировка файла mid/mif
            # для слоя устанавливается система координат
            crs = QgsProject.instance().crs()
            new_layer.setCrs(crs)
            QgsProject.instance().addMapLayer(new_layer, False)

            # слой сохраняется в группе
            target_group.insertLayer(1, new_layer)
            self.log('Слой {} добавлен к группе {}'.format(title, target_group.name()),
                0, False
            )

            try:
                self.make_map_fields(self.dict_fields, new_layer, self.nsi_interface)
            except Exception as e:
                self.log(
                    'Не удалось определить справочные значения для формы редактирования слоя {}: {}'
                    .format(title, str(e))
                )

        self.iface.mainWindow().blockSignals(False)
            
    def create_group(self):
        """Создает группу 'Локальные файлы' в панели слоев QGIS"""
        apgr_group = QgsProject.instance().layerTreeRoot().findGroup('Слои АПГР - mid/mif')
        if not apgr_group:
            apgr_group = QgsProject.instance().layerTreeRoot().addGroup('Слои АПГР - mid/mif')
            self.log("Создана группа слоев 'Слои АПГР - mid/mif'", 0, False)
        
        target_group = apgr_group.findGroup('Локальные файлы')
        if not target_group:
            target_group = apgr_group.addGroup('Локальные файлы')
            self.log("Создана группа слоев 'Локальные файлы'", 0, False)
        
        return target_group

    def select_files(self):
        """Диалоговое окно выбора файлов для загрузки в проект"""
        selected_files = QtWidgets.QFileDialog.getOpenFileNames(
            None, 'Выберите файлы', None,
            'TAB (*.tab);; MID/MIF (*.mif);; SHP(*.shp)'
        )[0]
        return selected_files
