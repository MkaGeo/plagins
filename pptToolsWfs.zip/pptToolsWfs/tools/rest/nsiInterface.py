# -*- coding: utf-8 -*-

from .smartInterface import SmartInterface


class NsiInterface(SmartInterface):
    """Интерфейс для справочников NSI"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def get_field_dict_vals(self, dict_nick, dic_field):
        """Возвращает список справочных значений для поля"""
        elements = self.get_dict_elements(dict_nick)
        codes = []
        values = []
        for element in elements:
            for value in element['values']:
                if value['nick'] == 'code':
                    codes.append(value['valueAttr'])

                if value['nick'] == dic_field:
                    values.append(value['valueAttr'])
        #удаляются null значения
        for i in reversed(range(len(codes))):
            if codes[i] is None or values[i] is None:
                codes.pop(i)
                values.pop(i)
        
        return codes, values
    
    def apgr_dict_fields(self):
        """Возвращает наименования справочных полей и 
        соответствующих справочников для слоев апгр"""
        dict_fields = {}
        for element in self.layers_dict_elements:
            layerName = None #имя слоя
            dictNick = None #код справочника
            fieldName = None #имя справочного поля
            dicField = None #Поле справочника
            multiple = None #Множественность значений

            for value in element['values']:
                if value['nick'] == 'layerName':
                    layerName = value['valueAttr']
                elif value['nick'] == 'fieldName':
                    fieldName = value['valueAttr']
                elif value['nick'] == 'dicNick':
                    dictNick = value['valueAttr']
                elif value['nick'] == 'dicField':
                    dicField = value['valueAttr']
                elif value['nick'] == 'multiple':
                    multiple = value['valueAttr']

                if not None in (layerName, dictNick, fieldName, dicField, multiple):
                    try:
                        dict_fields[layerName].append((fieldName, dictNick, dicField, multiple))
                    except KeyError:
                        dict_fields[layerName] = [(fieldName, dictNick, dicField, multiple)]
                    break

        return dict_fields