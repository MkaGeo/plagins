# -*- coding: utf-8 -*-

import requests
import json

from PyQt5.QtWidgets import QWidget, QLineEdit, QComboBox, QRadioButton, QTextEdit
from PyQt5.QtCore import QSettings
from qgis.core import QgsAuthMethodConfig, QgsApplication


def initialRequestsForm(dialog, layer, feature):
    """Заполнение аттрибутов первичных заявок"""
    if not dialog.findChild(QWidget, 'initRequestsCustomForm'):
        return

    buttonBox = dialog.findChild(QWidget,"buttonBox")
    buttonBox.accepted.connect(lambda: saveFeature(layer, feature, input_))
    searchButton = dialog.findChild(QWidget, "searchButton")

    input_ = {
        "oasiNumberPrefix": dialog.findChild(QWidget, "oasiNumberPrefix"),
        "oasi_number": dialog.findChild(QWidget, "oasiNumber"),
        "adres_orientir": dialog.findChild(QWidget, "address"),
        "namePPT": dialog.findChild(QWidget, "projectName"),
        "prim": dialog.findChild(QWidget, "notes"),
        "oasi_documentid": ""
    }

    try: # Проверят есть ли у объекта UUID (если UUID нет, то поля не заполняются)
        if len(feature['guid']) == 36:
            set_initial_form_vals(input_, feature)
    except:
        pass

    responseDocuments = []
    searchButton.clicked.connect(
        lambda: onOasiNumberSearchButtonClicked(
            input_,
            responseDocuments
        )
    )
    input_["oasi_number"].currentIndexChanged.connect(
        lambda: onOasiNumberChanged(
            input_,
            responseDocuments
        )
    )

def set_initial_form_vals(input_, feature):
    try:
        input_["oasiNumberPrefix"].setText(feature['oasi_number'])
    except:
        input_["oasiNumberPrefix"].setText('')
    
    try:
        input_["adres_orientir"].setText(feature['adres_orientir'])
    except:
        input_["adres_orientir"].setText('')
    
    try:
        input_["namePPT"].setText(feature['namePPT'])
    except:
        input_["namePPT"].setText('')
    
    try:
        input_["prim"].setPlainText(feature['prim'])
    except:
        input_["prim"].setPlainText('')

def onOasiNumberSearchButtonClicked(input_, responseDocuments):
    """Поиск заявок ПЗЗ по номеру заявки"""
    input_['oasi_number'].clear()

    authConfig = QgsAuthMethodConfig()
    authm = QgsApplication.authManager()
    authm.loadAuthenticationConfig(QSettings().value(
        'pptTools/authcfg'), authConfig, True
    )

    oasiIdRequestData = {
        "types": ["PPT"],
        "pageSize": 100,
        # "sort": "regDatePpt desc",
        "query": "numberOrder: *{}*".format(
            input_["oasiNumberPrefix"].text()
        )
    }
    url = QSettings().value('pptTools/oasi/host') + \
        QSettings().value('pptTools/oasi/requestsByTypeUrl')
    try:
        r = requests.post(
            url,
            auth=requests.auth.HTTPBasicAuth(
                authConfig.config('username'),
                authConfig.config('password')
            ),
            json=oasiIdRequestData
        )
        responseDocuments[:] = r.json()['response']['docs']
        oasiNums = [i['numberOrder'] for i in responseDocuments]
        input_['oasi_number'].addItems(oasiNums)
    except Exception as e:
        print('Connection to the server failed: {}. URL: {}'.format(r.text, url))


def onOasiNumberChanged(input_, responseDocuments):
    """Заполнение полей формы согласно номеру выбранной заявки ПЗЗ"""
    selectedOasiNumber = input_["oasi_number"].currentText()
    try:
        document = [i for i in responseDocuments if i['numberOrder']==selectedOasiNumber][0]
        input_['adres_orientir'].setText(document.get('address'))
        input_['namePPT'].setText(document.get('namePPT'))
        input_['oasi_documentid'] = document.get('documentId')
    except: 
        input_['adres_orientir'].setText('')
        input_['namePPT'].setText('')
        input_['oasi_documentid'] = ''


def saveFeature(layer, feature, input_):
    """Сохранение атрибутов объекта первичных заявок"""
    if input_["oasi_number"].currentText():
        oasiNumber = input_["oasi_number"].currentText()
    else:
        oasiNumber = input_["oasiNumberPrefix"].text()

    # feature.setAttribute("adres_orientir", input_["adres_orientir"].text())
    feature.setAttribute("oasi_number", oasiNumber)
    feature.setAttribute("oasi_documentid", input_["oasi_documentid"])

    feature.setAttribute("oasi_documentid", input_["oasi_documentid"]) #Временно! gid проекта приравнивается к gid документа 

    # feature.setAttribute("namePPT", input_["namePPT"].text())
    # feature.setAttribute("prim", input_["prim"].toPlainText())
    layer.updateFeature(feature)

        
        

    