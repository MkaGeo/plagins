# -*- coding: utf-8 -*-

import os
from qgis.core import QgsProject
from qgis.PyQt.QtXml import QDomDocument

from .baseTool import BaseTool

class FormPlan(BaseTool):
    """Формирование макета Ситуационного плана """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def set_layers(self):
        self.projectBordersLayer = QgsProject.instance().mapLayersByName(
            'Границы проекта')[0]
        self.admOkrugLayer = QgsProject.instance().mapLayersByName(
            'Границы округов')[0]

    def run(self):
        # self.set_layers()
        composer_name = 'situation_plan'
        # Определяем пересекает ли проект границы АО
        # project_border = next(self.projectBordersLayer.getFeatures())
        # areas = self.admOkrugLayer.getFeatures()
        # crosses = False
        # for area in areas:
        #     if project_border.geometry().overlaps(area.geometry()):
        #         crosses = True
        #         break

        # Загружается макет
        composition = self.createComposer(composer_name, '')

        # Если не пересекает границы АО, удаляем условное обозначение границ АО
        # if not crosses:
        #     composition.removeLayoutItem(
        #         composition.itemById('Легенда. Адм. границы')
        #     )
        #     composition.removeLayoutItem(
        #         composition.itemById('Легенда. Адм. границы. Текст')
        #     )
            