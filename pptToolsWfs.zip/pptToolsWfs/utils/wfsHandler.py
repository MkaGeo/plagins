# -*- coding: utf-8 -*-

from uuid import uuid4
from qgis.core import QgsProject, QgsDataSourceUri, QgsDataProvider
from PyQt5.QtCore import QObject


class WfsHandler(QObject):
    """Управление источниками данных WFS слоев"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # self.max_retries = kwargs['max_retries']
        self.max_retries = 3
    
    def reset(self):
        pass

    def read_project_layers(self):
        """Читает WFS слои проекта и назначает им триггерную функцию set_request_id,
        которая активируется при завершении редактирования слоя
        """
        for layer in QgsProject.instance().mapLayers().values():
            if layer.dataProvider().name().lower() == 'wfs':
                self.set_request_id(layer)
                layer.editingStopped.connect(self.set_request_id)
    
    def read_new_layer(self, layer):
        """Обрабатывает добавленный WFS слой"""
        if layer.dataProvider().name().lower() != 'wfs':
            return

        for i in range(int(self.max_retries)): #несколько попыток отправить запрос
            self.set_request_id(layer)
            if len([i.name() for i in layer.fields()]) > 0:
                break
        layer.editingStopped.connect(self.set_request_id)
    
    def set_request_id(self, layer=None):
        """Обновляет параметры URL WFS слоя.
        К URL добавляется параметр requestId со значением uuid
        """
        if not layer:
            layer = self.sender()

        uri = layer.dataProvider().dataSourceUri(False)
        temp_ds = QgsDataSourceUri(uri)
        temp_url = temp_ds.param('url')

        try:
            base, params = temp_url.split('?') #url и параметры http
        except ValueError:
            base = temp_url
            params = None

        if params: #считываются ключи и значения http параметов
            param_vals = dict(i.split('=') for i in params.split('&'))
        else:
            param_vals = {}
        
        #добавление/обновление параметра requestId
        param_vals['requestId'] = str(uuid4())
        param_vals['format_options'] = 'CHARSET:UTF-8'

        #формируется url с обновленным параметром requestId
        new_params = []
        for p, v in param_vals.items():
            new_params.append('='.join((p, v)))
        new_url = base+'?'+'&'.join(new_params)

        temp_ds.removeParam('url')
        temp_ds.setParam('url', new_url)

        layer.setDataSource(temp_ds.uri(False), layer.name(), 'WFS', QgsDataProvider.ProviderOptions())
        layer.reload() #обновление слоя