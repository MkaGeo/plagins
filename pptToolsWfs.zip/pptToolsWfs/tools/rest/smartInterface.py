# -*- coding: utf-8 -*-

import requests
import json
from .authManager import AuthManager

class SmartInterface:
    """
    Исполняет запросы к REST сервисам СМАРТ
    """
    headers = None
    def __init__(self, **kwargs):
        self.dicts_url = kwargs['host'] + kwargs['url_dict']
        self.layers_dict_nick = kwargs['layerFieldsDictNick']
        self.authManager = AuthManager(kwargs['authcfg'])
        print(self.headers)
        if not self.headers:
            self.headers = self.authManager.get_auth_headers()

    @property
    def layers_dict_elements(self):
        return self.get_dict_elements(self.layers_dict_nick)
    
    def get_dict_elements(self, dict_nick):
        """Отправляет запрос к API сервису справочников 
        на получение инфорамции о справочнике. 
        Возвращает список кодов элементов справочника."""
            
        r = requests.get(
            self.dicts_url + dict_nick,
            headers=self.headers
        )
        # print(json.dumps(r.json(encoding='utf-8')['dict']))
        try:
            return r.json(encoding='utf-8')['dict']['elements']
        except Exception as e:
            raise Exception(
                'Ошибка чтения справочника {}. Код {}: {}'
                .format(dict_nick, str(r.status_code), r.text)
            )
