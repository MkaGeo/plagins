# -*- coding: utf-8 -*-
import requests
import json

from qgis.core import QgsAuthMethodConfig, QgsApplication

class AuthManager:
    """Менеджер аутентификации на платформах СМАРТ и ОАСИ"""    
    def __init__(self, qgisAuthcfg):
        self.qgisAuthcfg = qgisAuthcfg
    
    @staticmethod
    def read_authcfg(authcfg):
        """Читает конф. авторизации qgis"""
        authConfig = QgsAuthMethodConfig()
        authm = QgsApplication.authManager()
        authm.loadAuthenticationConfig(authcfg, authConfig, True)
        return authConfig
    
    def get_access_token(self):
        """Получает токен для доступа к REST сервисам оаси"""
        authConfig = self.read_authcfg(self.qgisAuthcfg)

        auth_params = json.loads(authConfig.config("oauth2config"))
        
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'cache-control': 'no-cache'
        }

        data = {
            'username': auth_params['username'],
            'password': auth_params['password'],
            'grant_type': 'password',
            'client_id': auth_params['clientId'],
            'client_secret': auth_params['clientSecret'],
        }

        r = requests.post(
            auth_params['tokenUrl'],
            headers=headers,
            data=data
        )
        if r.status_code != 200:
            raise Exception('{} - {}'.format(str(r.status_code), r.text))

        return r.json()['access_token']

    def get_auth_headers(self):
        try:
            token = self.get_access_token()
        except Exception as e:
            raise Exception(
                'Ошибка при получении токена: '+str(e)
            )

        return {
            'authorization': 'Bearer {}'.format(token)
        }