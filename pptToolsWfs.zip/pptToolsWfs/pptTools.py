# -*- coding: utf-8 -*-

import os
import sys
import yaml
import json
from datetime import datetime
from PyQt5.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction
from qgis.core import QgsExpressionContextUtils,\
    QgsProject, QgsApplication, QgsDataSourceUri, QgsAuthMethodConfig

from .tools.formPlan import FormPlan
from .tools.startNewProject import StartNewProject
from .tools.setNewProject import SetNewProject
from .tools.importApgr import ImportApgr
from .tools.exportApgr import ExportApgr
from .tools.openFiles import OpenFiles
from .tools.setProjectTool import SetProjectTool
from .tools.resetProject import ResetProjectTool
from .utils.wfsHandler import WfsHandler
# from .tools.infoTool import InfoTool
from .ui.constructors import ImportApgrDlg, ExportApgrDlg, \
    LoadDb2Dlg, SearchProjectDlg
from .tools.rest.nsiInterface import NsiInterface


class PptTools:
    """Интерфейс инструментов плагина ППТ"""
    config_file_name = 'config.yml'

    def __init__(self, iface):
        self.tools = {}
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        try:
            locale = QSettings().value('locale/userLocale')[0:2]
            locale_path = os.path.join(
                self.plugin_dir,
                'i18n',
                'pptTools_{}.qm'.format(locale))

            if os.path.exists(locale_path):
                self.translator = QTranslator()
                self.translator.load(locale_path)

                if qVersion() > '4.3.3':
                    QCoreApplication.installTranslator(self.translator)
        except:
            pass
        
        try:
            config_file = os.path.join(
                self.plugin_dir,
                self.config_file_name
            )
            with open(config_file, 'r') as f:
                self.config = self.readConfig(yaml.load(f))
        except Exception as e:
            self.log("Не удалось загрузить конфигурацию из файла: {}".format(config_file), 2)
            raise Exception("Could not load config file {}: {}".format(config_file, str(e)))

        self.actions = []
        self.menu = self.tr('&ppt tools')
        self.toolbar = self.iface.addToolBar('PptToolsBar')
        self.toolbar.setObjectName('PptToolsBar')
        self.wfs_handler = WfsHandler()
        self.nsi_interface = NsiInterface(**self.config['smart'])

    def tr(self, message):
        """
        """
        return QCoreApplication.translate('pptTools', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Инициализация GUI плагина. Активация инструментов"""
        tool_args = {
            'iface': self.iface,
            'switchActions': self.setToolsActiveStatus,
            'log': self.log,
            'log_multiple': self.log_multiple,
            'tr': self.tr,
            'config': self.config,
            'plugin_dir': self.plugin_dir,
            'dialog': None,
            'wfs_handler': self.wfs_handler,
            'nsi_interface': self.nsi_interface
        }
        for tool_name, tool_config in \
            sorted(self.config['tools'].items(), key=lambda x: x[1]['position']):
            if tool_config['enabled']:
                _cls = getattr(sys.modules[__name__], tool_config['className'])# имя класса инструмента
                # Если для инструмента определен UI dialog, то передается соответствующий класс
                if tool_config['dialog']:
                    tool_args['dialog'] = getattr(sys.modules[__name__], tool_config['dialog'])

                self.tools[tool_name] =_cls(**tool_args)
                tool_icon = ':/icons/' + tool_config['icon'] if tool_config['icon'] else None
                self.add_action(
                    icon_path=tool_icon,
                    text=self.tr(tool_name),
                    callback=self.tools[tool_name].run,
                    enabled_flag=False,
                    parent=self.iface.mainWindow()
                )
        
        # Если проект уже загружен, считываем слои и активируем инструменты
        if QgsProject.instance().fileName():
            # self.readLayers()
            self.setToolsActiveStatus()
        
        # Дополнительные действия при открытии проекта
        self.iface.projectRead.connect(self.onProjectRead)

    def unload(self):
        """Удаляет элементы меню плагина"""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr('&PPT Tools'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def setToolsActiveStatus(self, activate=True):
        """Активация и деактиваци инструментов плагина"""
        numberOrder = QgsExpressionContextUtils.projectScope(
            QgsProject.instance()
        ).variable('numberOrder')

        for action in self.actions:
            if numberOrder or action.text() == 'Новый проект' \
                or action.text() == 'Загрузить слои АПГР' \
                or action.text() == 'Выгрузить слои АПГР' \
                or action.text() == 'Открыть локальные файлы' \
                or action.text() == 'Настройка проекта' \
                or action.text() == 'Выбрать проект':
                action.setEnabled(True)
            else:
                action.setDisabled(True)

    def readConfig(self, config_data):
        settings = QSettings()
        config = {}
        # wfs connection
        config["wfsConnection"] = config_data["wfsConnection"]
        config["wfsLayers"] = config_data["wfsLayers"]
        config['bordersLayer'] = config_data["bordersLayer"]
        config['borderTypeApgrExport'] = config_data["borderTypeApgrExport"]
        config['oasi'] = config_data["oasi"]
        config['smart'] = config_data["smart"]
        self.check_auth(config['oasi'])
        self.check_auth(config['smart'])
        for attr, val in config['oasi'].items():
            settings.setValue('pptTools/oasi/'+attr, val)

        config['plugin_dir'] = self.plugin_dir
        config['tools'] = config_data['tools']
        return config
    
    def check_auth(self, settings):
        authm = QgsApplication.authManager()
        method = authm.configAuthMethodKey(settings['authcfg'])
        if not method:
            self.log(
                "Отсутствует конфигурация для аутентификации: {}".format(settings['authcfg']), 1
            )
            raise Exception("Configuration setting not found: {}".format(settings['authcfg']))
    
    def log(self, message, level=0, showMessageBar=True, logFileName=None):
        """Логирование сообщения"""
        # Сообщение пишется в лог и выводится на экран
        QgsApplication.messageLog().logMessage(
            self.tr(message), 'pptTools', level
        )
        # Панель с сообщениями
        if showMessageBar:
            self.iface.messageBar().pushMessage(
                self.tr(message),
                level=level
            )
        # Запись сообщения в файл
        if logFileName:
            self.wrilteLogFile(logFileName, [message])
    
    def log_multiple(self, messages, level=0, logFileName=None):
        """Логирование множественных сообщений"""
        messages = [i for i in messages if isinstance(i, str)]
        self.log('\n'.join(messages), level, False, False)
        # Запись сообщения в файл
        if logFileName:
            self.wrilteLogFile(logFileName, messages)
    
    def wrilteLogFile(self, logFileName, messages):
        """Запись лог сообщений в файл"""
        try:
            project_path = QgsExpressionContextUtils.projectScope(
                QgsProject.instance()
            ).variable('project_path')
            project_dir = os.path.dirname(project_path)
            log_dir = os.path.join(project_dir, 'log')
            if not os.path.isdir(log_dir):
                os.mkdir(log_dir)
            
            logFileName = os.path.join(log_dir, logFileName)
            
            if os.path.isfile(logFileName):
                with open(logFileName, 'r') as f:
                    lines = f.readlines()
            else:
                lines = []

            for message in messages:
                lines.append(
                    '  '.join([datetime.now().strftime("%Y-%m-%dT%H:%M:%S:%f"), message])+'\n'
                )

            with open(logFileName, 'w') as f:
                f.writelines(lines)
        except Exception as e:
            self.log("Не удалось записать сообщение в файл {}: {}"
                .format(logFileName, str(e)), 1, False)
    
    def read_wfs_username(self):
        """Сохраняет имя пользователя WFS в переменную проекта"""
        try:
            authConfig = QgsAuthMethodConfig()
            authm = QgsApplication.authManager()
            authm.loadAuthenticationConfig(
                self.config['wfsConnection']['authcfg'],
                authConfig, True
            )
            wfs_user = json.loads(authConfig.config("oauth2config"))['username']
        except: 
            wfs_user = ''
        
        QgsExpressionContextUtils.setProjectVariable(
            QgsProject.instance(), 'wfs_user', wfs_user
        )
        

    def onProjectRead(self):
        """Действия при открытии проекта"""
        self.setToolsActiveStatus()
        self.wfs_handler.reset()
        self.wfs_handler.read_project_layers()
        self.read_wfs_username()

