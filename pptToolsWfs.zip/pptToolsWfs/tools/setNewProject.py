# -*- coding: utf-8 -*-

from qgis.core import QgsProject, QgsExpressionContextUtils, QgsFeatureRequest
from qgis.gui import QgsMapToolIdentifyFeature

from .baseTool import BaseTool

class SetNewProject(BaseTool):
    """Настройка проекта"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def set_layers(self):
        self.initRequestsLayer = QgsProject.instance().mapLayersByName(
            'Первичные заявки ППТ')[0]
        # self.projectBordersLayer = QgsProject.instance().mapLayersByName(
        #     'Границы проектов')[0]

    def run(self):
        self.set_layers()
        self.iface.setActiveLayer(self.initRequestsLayer)
        self.mapTool = QgsMapToolIdentifyFeature(self.iface.mapCanvas())
        self.mapTool.setLayer(self.initRequestsLayer)
        self.iface.mapCanvas().setMapTool(self.mapTool)
        self.mapTool.featureIdentified.connect(self.onFeatureIdentified)
    
    def onFeatureIdentified(self, feature):
        self.iface.mapCanvas().unsetMapTool(self.mapTool)
        try:
            self.mapTool.featureIdentified.disconnect(self.onFeatureIdentified)
        except:
            pass

        # Set project variables
        # project_name = feature.attribute('namePPT')
        project_num = feature.attribute('oasi_documentid')
        oasi_num = feature.attribute('oasi_number')

        # QgsExpressionContextUtils.setProjectVariable(
        #     QgsProject.instance(),
        #     'project_name', project_name
        # )
        QgsExpressionContextUtils.setProjectVariable(
            QgsProject.instance(),
            'documentId', project_num
        )
        QgsExpressionContextUtils.setProjectVariable(
            QgsProject.instance(),
            'numberOrder', oasi_num
        )

        # Filter layers
        self.initRequestsLayer.setSubsetString("oasi_number = '%s'" % oasi_num)
        # self.projectBordersLayer.setSubsetString("initial_request_guid = '%s'" % project_num)

        self.switchActions()
