
import unittest
import sys

from tools.exportApgr import ExportApgr
# from tools.baseTool import BaseTool




class TestDbAdapter(unittest.TestCase):
    apgr_tables_layer_name = 'apgr_apgr_tables'

    def setUp(self):
        self.export_tool = ExportApgr()
        # self.export_tool.apgr_tables_layer = 
    
    def tearDown(self):
        self.export_tool = None

    # def test_geoserver_connection(self):
    #     uri = 
    
    def test_read_layer_info(self):
        layers_info = self.export_tool.read_layers_info()
        print(layers_info)
        

if __name__ == '__main__':
    unittest.main()