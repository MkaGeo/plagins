# -*- coding: utf-8 -*-

def classFactory(iface):  # pylint: disable=invalid-name
    """Load PptTools class from file PptTools.

    :param iface: A QGIS interface instance.
    :type iface: QgisInterface
    """
    
    from .pptTools import PptTools
    return PptTools(iface)
