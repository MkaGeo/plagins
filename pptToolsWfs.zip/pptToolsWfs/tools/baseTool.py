# -*- coding: utf-8 -*-

import os
import json
import re

import psycopg2
from datetime import datetime
from PyQt5.QtWidgets import QMainWindow
from qgis.core import QgsAuthMethodConfig, QgsApplication, QgsProject, \
    QgsPrintLayout, QgsExpressionContextUtils, QgsReadWriteContext, QgsEditorWidgetSetup, \
    QgsFeatureRequest, QgsDataSourceUri, Qgis, QgsVectorLayer, QgsCoordinateReferenceSystem
from qgis.PyQt.QtWidgets import QProgressBar
from PyQt5.QtCore import QSettings
from qgis.PyQt.QtXml import QDomDocument


class BaseTool(QMainWindow):
    """Базовый класс для инструментов плагина ППТ"""
    
    project_variables = [
        'documentId', 'numberOrder', 'address', 'projectCode'
    ]

    def __init__(self, **kwargs):
        super().__init__()
        self.iface = kwargs['iface']
        self.switchActions = kwargs['switchActions']
        self.log = kwargs['log']
        self.log_multiple = kwargs['log_multiple']
        self.config = kwargs['config']
        self.plugin_dir = kwargs['plugin_dir']
        self.document_id = ''
        self.apgrLayersPrefix = self.config['wfsLayers']['apgrLayersPrefix']
        self.apgrTables = self.config['wfsLayers']['apgrTables']
        self.apgrVersions = self.config['wfsLayers']['apgrVersions']
        #id поле объектов в таблицах АПГР
        self.feature_id_field = self.config['wfsLayers']['featureIdField']
        #поле списка id объектов в apgr_versions
        self.version_feature_ids_field = self.config['wfsLayers']['versionFeatureIdsField']
        #управление слоями WFS
        self.wfs_handler = kwargs['wfs_handler']

        self.apgr_tables_layer = None
        self.apgr_versions_layer = None
        self.filtered_layers = [self.config['bordersLayer']]
        # self.nsi_interface = NsiInterface(**self.config['smart'])
        self.nsi_interface = kwargs['nsi_interface']
        
    def read_meta_tables(self):
        """Загружает слои с информацией о таблицаx АПГР и версиях загруженных данных"""
        self.apgr_tables_layer = self.make_wfs_layer(
            self.apgrLayersPrefix+self.config['wfsLayers']['apgrTables']
        )
        self.apgr_versions_layer = self.make_wfs_layer(
            self.apgrLayersPrefix+self.config['wfsLayers']['apgrVersions']
        )
    
    def read_all_layers_info(self):
        """Читает данные об источниках слоев из таблицы apgr_tables"""
        layers_info = {}

        for f in self.apgr_tables_layer.getFeatures():
            layers_info[f['mid_mif_name']] = {
                'gid_table': f['gid_table'],
                'group_name': f['group_name'],
                'group_name_ru': f['group_name_ru'],
                'table_name': f['table_name'],
            }

        return layers_info
    
    def current_user(self):
        """Возвращает имя пользоваеля, указанное в кноф-ии аутентификации oauth2"""
        authConfig = QgsAuthMethodConfig()
        authm = QgsApplication.authManager()
        authm.loadAuthenticationConfig(
            self.config['wfsConnection']['authcfg'],
            authConfig, True
        )
        try:
            return json.loads(authConfig.config("oauth2config"))['username']
        except: 
            return None
    
    @staticmethod
    def make_map_fields(dict_fields, layer, nsi_interface):
        """Формирует виджет 'Карта значений' 
        на основе данных справочника для загружаемого слоя
        """
        
        if layer.name() in dict_fields:
            # print(dict_fields[layer.name()])
            dict_vals = {}
            for field_name, dict_nick, dic_field, multiple in dict_fields[layer.name()]:
                if not multiple: #карта значений формируется только для немножественных полей
                    codes, aliases = nsi_interface.get_field_dict_vals(dict_nick, dic_field)
                    dict_vals[field_name] = list(zip(codes, aliases))#справочные значения полей
            # print(dict_vals)
            for i, field in enumerate(layer.fields()):
                if field.name().lower() in dict_vals:
                    # print(dict_vals[field.name().lower()])
                    #формируется виджет 'Карта значений'
                    widget_setup = QgsEditorWidgetSetup( 'ValueMap', {
                        'map': {i[1]: i[1] for i in dict_vals[field.name().lower()]}
                    })
                    layer.setEditorWidgetSetup(i, widget_setup)
    

    def read_dic_fields(self):
        """"""
        try:
            return self.nsi_interface.apgr_dict_fields()
        except Exception as e:
            self.log('Ошибка чтения справочников АПГР: {}'.format(str(e)), 1)
            return {}
    
    @staticmethod
    def get_oasi_number():
        """Возвращает номер заявки активного проекта"""
        oasi_num = QgsExpressionContextUtils.projectScope(
            QgsProject.instance()
        ).variable('numberOrder')
        return oasi_num
    
    @staticmethod
    def get_project_title():
        """Возвращает название активного проекта"""
        namePPT = QgsExpressionContextUtils.projectScope(
            QgsProject.instance()
        ).variable('namePPT')
        return namePPT
    
    @staticmethod
    def get_project_address():
        """Возвращает адрес активного проекта"""
        address = QgsExpressionContextUtils.projectScope(
            QgsProject.instance()
        ).variable('address')
        return address
    
    @staticmethod
    def get_document_id():
        """Возвращает guid активного проекта"""
        project_num = QgsExpressionContextUtils.projectScope(
            QgsProject.instance()
        ).variable('documentId')
        return project_num

    def natural_keys(self, text):
        """Человеческая сортировка (Если имеются числа, проверять их цельно, а не поциферно)"""
        return [self.atoi(c) for c in re.split(r'(\d+)', text)]

    def atoi(self, text):
        """Перевод строки в число, если возможно"""
        return int(text) if text.isdigit() else text

    def get_project_geom(self):
        """Возвращает геометрию активного проекта 
        из слоя границ проекта, найденного по id документа
        """
        document_id = self.get_document_id()

        initialRequestsLayer = QgsProject.instance().mapLayersByName(
            self.config['bordersLayer']
        )[0]
        request = QgsFeatureRequest().setFilterExpression(
            "oasi_documentid = '{}' and border_type_code = '{}'"
            .format(document_id, self.config['borderTypeApgrExport'])
        )
        
        try:
            feature = next(initialRequestsLayer.getFeatures(request))
            return feature.geometry()
        except StopIteration:
            return None
    
    def log_file_name(self, version):
        """Формирует имя лог файла из номера заявки, версии и времени"""
        oasi_num = self.get_oasi_number()
        timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S-%f")
        return '--'.join((oasi_num, version, timestamp))+'.txt'
    
    def make_wfs_layer(self, wfs_layer_name):
        """Возвращает WFS слой, полученный по имени слоя"""
        uri = self.get_wfs_uri(wfs_layer_name)
        layer = QgsVectorLayer(uri.uri(False), wfs_layer_name, 'WFS')
        crs = QgsProject.instance().crs()
        layer.setCrs(crs)
        # layer.setProviderEncoding('utf-8')
        self.wfs_handler.read_new_layer(layer)

        return layer

    def get_wfs_uri(self, layer_name):
        """Создает объект источника слоя QGIS"""
        uri = QgsDataSourceUri()
        uri.setParam('url', self.config['wfsConnection']['url'])
        uri.setParam('version', self.config['wfsConnection']['version'])
        uri.setParam('typename', ':'.join([self.config['wfsConnection']['workspace'], layer_name]))
        uri.setParam('authcfg', self.config['wfsConnection']['authcfg'])

        return uri
       
    def make_progress_bar(self, steps, message):
        """Создает progress bar, отображающий процесс загрузки"""
        progressMessageBar = self.iface.messageBar().createMessage(message)
        progress = QProgressBar()
        progress.setMaximum(steps)
        progressMessageBar.layout().addWidget(progress)
        self.iface.messageBar().pushWidget(progressMessageBar, Qgis.Info)
        return progressMessageBar, progress

    def cleanupComposers(self, name):
        """Удаляет шаблон, найденный по имени name"""
        layoutsManager = QgsProject.instance().layoutManager()
        for layout in layoutsManager.layouts():
            if name in layout.name():
                layoutsManager.removeLayout(layout)

    def createComposer(self, name, postfix):
        """Загружает макет из файла найденного по имени name"""
        self.cleanupComposers(name)
        layout = QgsPrintLayout(QgsProject.instance())
        # Шаблоны хранятся в папке плагина
        template_dir = os.path.join(self.plugin_dir, 'templates')
        template = os.path.join(template_dir, name + '.qpt')
        try:
            doc = QDomDocument()
            with open(template, 'r') as f:
                doc.setContent(f.read())
        except:
            self.log("Не удалось загрузить макет документа: {}".format(template), 1)
            return
        
        layout.loadFromTemplate(doc, QgsReadWriteContext())
        layout.setName(name+postfix)
        QgsProject.instance().layoutManager().addLayout(layout)
        layout = QgsProject.instance().layoutManager().layoutByName(name+postfix)
        self.iface.openLayoutDesigner(layout)
        return layout