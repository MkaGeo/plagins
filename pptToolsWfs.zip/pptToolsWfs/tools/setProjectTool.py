# -*- coding: utf-8 -*-

import requests
from qgis.core import QgsProject, QgsExpressionContextUtils, QgsFeatureRequest, \
    QgsAuthMethodConfig, QgsApplication
from PyQt5.QtCore import QSettings
from qgis.gui import QgsMapToolIdentifyFeature
from PyQt5.QtWidgets import QWidget, QLineEdit, QComboBox, QRadioButton, QTextEdit, QDialogButtonBox

from .baseTool import BaseTool

class SetProjectTool(BaseTool):
    """Настройка проекта"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dlg = kwargs['dialog']()

        self.button_box = self.dlg.findChild(QWidget,"buttonBox")
        self.search_button = self.dlg.findChild(QWidget, "searchButton")
        self.project_type_select = self.dlg.findChild(QWidget, "projectType")
        self.oasi_number_input = self.dlg.findChild(QWidget, "oasiNumberPrefix")
        self.oasi_number_select = self.dlg.findChild(QWidget, "oasiNumber")
        self.adress_text = self.dlg.findChild(QWidget, "textAddress")
        self.project_name_text = self.dlg.findChild(QWidget, "textProjectName")
    
        self.button_box.accepted.connect(self.set_project)
        self.search_button.clicked.connect(self.search_documents)
        self.oasi_number_select.currentIndexChanged.connect(self.select_document)
        # self.project_type_select.currentIndexChanged.connect(self.select_project_type)
    
        self.reset()
    
    def reset(self):
        self.responseDocuments = []
        self.responseProjectTypes = []
        self.project_type = ''
        self.project_type_code = ''
    
    def run(self):
        self.dlg.show()

    def search_documents(self):
        """Осуществляется поиск документов по совпадению номеров.
        Заполняет выпадающий список найденными номерами"""
        authConfig = QgsAuthMethodConfig()
        authm = QgsApplication.authManager()
        authm.loadAuthenticationConfig(self.config['oasi']['authcfg'], authConfig, True)

        oasiIdRequestData = {
            "types": ["PPT"],
            "pageSize": 100,
            "query": "numberOrder: *{}*".format(self.oasi_number_input.text())
        }

        url = self.config['oasi']['host'] + self.config['oasi']['requestsByTypeUrl']
        try:
            r = requests.post(
                url,
                auth=requests.auth.HTTPBasicAuth(
                    authConfig.config('username'),
                    authConfig.config('password')
                ),
                json=oasiIdRequestData
            )
            print(oasiIdRequestData)
            print(url)
            print(r.status_code)
            print(r.json())
            self.responseDocuments = r.json(encoding='utf-8')['response']['docs']
            self.oasi_number_select.clear()
            self.oasi_number_select.addItems(
                [i['numberOrder'] for i in self.responseDocuments]
            )

        except Exception as e:
            self.log('Не удалось найти документы по номеру: {}'.format(r.text), 1)
        
    # def select_project_type(self):
    #     """Выбор типа проекта из выпадающего списка"""
    #     selected_document = self.selected_project_type()
    #     self.project_type = selected_document['']
    #     self.project_type_code = selected_document['']
    
    # def selected_project_type(self):
    #     return self.responseProjectTypes[
    #         self.project_type_select.currentText()
    #     ]
    
    def select_document(self):
        """Выбор номера документа из выпадающего списка"""   
        try:
            document = self.selected_document()
            self.adress_text.setText(document.get('address', ''))
            self.project_name_text.setText(document.get('namePPT', ''))
            self.button_box.button(QDialogButtonBox.Ok).setEnabled(True)
        except Exception as e: #если ошибка, кнопка Ок неактивна
            self.adress_text.setText('')
            self.project_name_text.setText('')
            self.button_box.button(QDialogButtonBox.Ok).setEnabled(False)
    
    def selected_document(self):
        """Возвращает документ из списка с номером, соотв. выбранному"""
        oasi_number = self.oasi_number_select.currentText()
        document = [i for i in self.responseDocuments if i['numberOrder']==oasi_number][0]
        return document

    def set_project(self):
        """Настройка слоев и переменных проекта в соответствие с выбранным документом"""
        try:
            document = self.selected_document()
        except:
            return
        self.log('Настройка на проект. Номер: {}, название: {}, адрес: {}'.format(
            document.get('numberOrder', ''),
            document.get('namePPT', ''),
            document.get('address', ''),
        ))

        #заполняются переменные проекта
        for attr in self.project_variables:
            QgsExpressionContextUtils.setProjectVariable(
                QgsProject.instance(), attr, document.get(attr, '')
            )
        #номер и имя документа отображаются в заголовке окна qgis
        if document.get('numberOrder'):
            self.iface.mainWindow().setWindowTitle(
                document.get('numberOrder', '') + '-' + document.get('namePPT', ''))
        
        #фильтр слов по номеру заявки
        filter_string = "oasi_documentid = '{}'".format(document.get('documentId', ''))
        for layer_name in self.filtered_layers:
            layer = QgsProject.instance().mapLayersByName(layer_name)[0]
            layer.setSubsetString(filter_string)
        
        self.switchActions()
        
