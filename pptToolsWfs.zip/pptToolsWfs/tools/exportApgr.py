# -*- coding: utf-8 -*-

import os
import json
from uuid import uuid4
import requests
import time
from datetime import datetime
import xml.etree.ElementTree as ET
from psycopg2 import sql
from PyQt5 import QtWidgets
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsAuthMethodConfig, QgsApplication, QgsDataSourceUri, edit, QgsFeature,\
    QgsVectorLayer, QgsVectorFileWriter, QgsProject, QgsFeatureRequest, QgsExpressionContextUtils, \
    QgsLayerTreeGroup, QgsLayerTreeLayer, QgsVectorLayerExporter, QgsCoordinateReferenceSystem, \
    QgsRectangle, NULL, QgsVectorLayerUtils, QgsTask, QgsField
from .baseTool import BaseTool
# from .rest.nsiInterface import NsiInterface

class ExportApgr(BaseTool):
    """Инструмент загрузки слоев в базу данных АПГР.
    Список слоев, доступных для загрузки, формируется из слоев
    и подгрупп, входящих в группу Слои АПГР - mid/mif.
    Доступно два варианта загрузки: 1) Первичная загрузка,
    2) Загрузка в рамках проекта ППТ. При первом варианте, в таблицах,
    соответствующих слоям создаются записи для всех загружаемых объектов без проверки
    различия с исходными объектами и создается новая 'мастер - версия'.
    При втором варианте производится проверка загружаемых объектов
    с исходными объектами, определенными по feature_id. В случае, если обнаружены различия,
    новый объект сохраняется, иначе в запись о версии вносится feature_id имеющегося объекта
    """
    field_types_defaults = {
        (QVariant.Char, QVariant.String): 'N/A',
        (QVariant.Int, QVariant.Double): -9999,
        (QVariant.Bool): False,
    } # коды типов полей и значения по-умолчанию. Используется для заполнения null полей

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dlg = kwargs['dialog']()
        self.dlg.comboBoxGroup.currentIndexChanged.connect(self.onGroupChanged)
        self.dlg.checkBoxInitialUpload.toggled.connect(self.onInitialUploadChecked)
        self.dlg.checkBoxGenerateDefaults.toggled.connect(self.onGenerateDefaultsChecked)
        self.dlg.checkBoxInitialUpload.setChecked(True)
        self.new_features = False
    
    def reset(self):
        """Сбрасывает значения атрибутов"""
        self.document_id = ''
        self.oasi_number = ''
        self.gid_change = ''
        self.logFileName = ''
        self.layers_info = {}
        self.apgr_group = None
        self.version_origin = None
        self.version_target = None
        self.initialUpload = self.dlg.checkBoxInitialUpload.isChecked()
        self.generateDefaults = self.dlg.checkBoxGenerateDefaults.isChecked()
        self.uploaded_features = {}
        self.errors = []

        self.read_meta_tables()

        # Информация об источниках данных слоев
        self.layers_info = self.read_all_layers_info()
        if not self.layers_info:
            self.log('Ошибка чтения таблицы {}.'.format(self.config['wfsLayers']['apgrTables']), 1)
            return False
        # Данные справочников слоев АПГР

        try:
            # self.nsi_interface = NsiInterface(**self.config['smart'])
            self.dict_fields = self.nsi_interface.apgr_dict_fields()
        except Exception as e:
            self.log('Ошибка чтения справочников АПГР: {}. \
                Проверка справочных полей не может быть произведена'.format(str(e)), 1)
            self.dict_fields = {}
        return True
    
    def run(self):
        all_good = self.reset()
        if not all_good:
            return
        # Номер активного проекта
        self.document_id = self.get_document_id()
        if not self.document_id:
            self.log("Не удалось прочесть номер проекта. Необходимо настроиться на проект", 1)
            return
        
        # Номер заявки ОАСИ
        self.oasi_number = self.get_oasi_number()
        if not self.oasi_number or self.oasi_number == NULL:
            self.log("Не удалось установить номер первичной заявки ППТ", 1)
            return
        
        # Для загрузки данных необходимо наличие группы 'Слои АПГР - mid/mif',
        # которая содержит загружаемые слои
        self.apgr_group = QgsProject.instance().layerTreeRoot().findGroup('Слои АПГР - mid/mif')
        if not self.apgr_group:
            self.log("Не найдена группа 'Слои АПГР - mid/mif'", 1)
            return

        # Заполняется список выбора группы слоев
        self.dlg.comboBoxGroup.clear()
        self.dlg.comboBoxGroup.addItems(
            [i.name() for i in self.apgr_group.findGroups()]
        )
        self.dlg.show()
        result = self.dlg.exec_()
        if result:
            self.new_features = False
            # Выбранные источники данных в соответствие с выбранными слоями
            selected_layer_sources = self.read_checked_sources()
            # Номера исходной и целевой версии данных
            self.version_origin, self.version_target = self.read_versions(selected_layer_sources)
            
            if not self.version_target:
                self.log("Не удалось опредилить целевую версию загружаемых данных", 1)
                return
                
            # Имя лог файла для записи протокола проверки и загрузки данных
            self.logFileName = self.log_file_name(self.version_target)

            # Загружаемые данные сверяются с целевыми таблицами
            self.errors += self.validate_layers(selected_layer_sources)
            self.log('Валидация загружаемых данных. Обнаружено проблем: {}'
                .format(len(self.errors)), 1, False, logFileName=self.logFileName)
            if self.errors:
                self.log_multiple(self.errors, level=1, logFileName=self.logFileName)
                QMessageBox.warning(
                    None, '', '\n'.join(
                        ['Обнаружены ошибки при валидации данных.',
                        'Подробная информация в окне сообщений pptTools']) 
                )
                return
            self.errors = []
            # Слои загружаются в базу данных
            progressMessageBar, progress = self.make_progress_bar(
                len(selected_layer_sources), "Загрузка слоев в базу данных..."
            ) # Панель прогресса загрузки
            self.iface.mainWindow().blockSignals(True)
            try:
                self.upload_layers(selected_layer_sources, progress)
            except Exception as e:
                self.log('Возникла ошибка при загрузке данных: {}'.format(str(e)), 
                    logFileName=self.logFileName)
                self.rollback()
            self.iface.mainWindow().blockSignals(False)
            self.iface.messageBar().popWidget(progressMessageBar)

    def check_empty_layers(self, layers):
        errors = []
        for i, (layer_id, layer_source) in enumerate(layers.items()):
            layer = QgsProject.instance().layerTreeRoot().findLayer(layer_id).layer()
            if len(list(layer.getFeatures())) != 0:
                return []
        errors.append(u"Все выбранные слои пустые!")
        return errors

    def onInitialUploadChecked(self):
        """Действия при активации/деактивации опции 'Первичная загрузка'"""
        self.initialUpload = self.dlg.checkBoxInitialUpload.isChecked()
    
    def onGenerateDefaultsChecked(self):
        """Действия при активации/деактивации опции 'Сгенерировать значения по умолчанию'"""
        self.generateDefaults = self.dlg.checkBoxGenerateDefaults.isChecked()

    def onGroupChanged(self):
        """Действия при выборе группы загружаемых слоев"""
        # Поиск подгрупп внутри выбранной группы
        try:
            selected_project_group = [
                g for g in self.apgr_group.findGroups()
                if g.name() == self.dlg.comboBoxGroup.currentText()
            ][0]

        except IndexError:
            return

        layout = QtWidgets.QVBoxLayout()
        frame = QtWidgets.QFrame()
        # Если в выбранной группе имеются погруппы,
        # groupBox-ы формируются для каждой подгруппы
        if selected_project_group.findGroups():
            for group in selected_project_group.findGroups():
                # Для каждой погруппы создается QGroupBox
                self.create_group_boxes(group, layout)
        else: # иначе, формируется один groupBox
            self.create_group_boxes(selected_project_group, layout)

        frame.setLayout(layout)
        self.dlg.scrollAreaLayers.setWidget(frame)

    def create_group_boxes(self, group, layout):
        """Создает группы checkbox, для каждого слоя группы.
        Добавляет созданные группы к layout
        """
        groupBox = QtWidgets.QGroupBox(group.name())
        groupBox.toggled.connect(self.group_box_checked)
        groupBox.setCheckable(True)
        groupBox.setChecked(False)
        groupBox_layout = QtWidgets.QVBoxLayout()
        groupBox.setLayout(groupBox_layout)
        layout.addWidget(groupBox)
        # Для каждого слоя внутри погруппы создается QCheckBox
        for layer in group.findLayers():
            # Вставляет checkbox
            check_box = QtWidgets.QCheckBox(layer.name())
            # Задается имя виджета, совпадающее с id соотв. слоя
            check_box.setAccessibleName(layer.layerId())
            font = check_box.font()
            font.setBold(False)
            check_box.setFont(font)
            # Виджет добавляется к groupbox
            groupBox_layout.addWidget(check_box)

    def group_box_checked(self):
        """Действия при активации/деактивации группы QGroupBox"""
        for box in self.sender().findChildren(QtWidgets.QCheckBox):
            box.setChecked(self.sender().isChecked())
            box.setEnabled(True)
    
    def read_checked_sources(self):
        """Формирует источники данных для выбранных слоев"""
        selected_layer_sources = {}
        for box in self.dlg.scrollAreaLayers.widget().findChildren(QtWidgets.QCheckBox):
            if box.checkState():
                # Формируется словарь, содержащий источники данных для каждого выделенного слоя
                try:
                    selected_layer_sources[box.accessibleName()] = self.layers_info[box.text()]
                except KeyError:
                    self.errors.append(
                        'Не удалось определить целевую таблицу для слоя {}'.format(box.text())
                    )
        return selected_layer_sources
    
    def read_versions(self, layer_sources):
        """Определение исходной и целевой версии данных"""
        version_origin = None
        # Номер целевой версии загружаемых данных
        try:
            version_target = self.get_target_version_number()
            self.validate_version_format(version_target)# Проверка правильности формата номера целевой версии
        except:
            version_target = None

        return version_origin, version_target

    @staticmethod
    def validate_version_format(version):
        """Проверка формата номера версии"""
        version = list(map(int, version.split('.')))
        if len(version) != 2:
            raise TypeError('Неверный формат номера версии')

    def validate_layers(self, layer_sources):
        print(self.dict_fields)
        """Предварительная проверка загружаемых данных"""
        errors = self.check_empty_layers(layer_sources)
        if errors:
            return errors
        progressMessageBar, progress = self.make_progress_bar(
            len(layer_sources), "Проверка загружаемых данных..."
        )
        self.iface.mainWindow().blockSignals(True)
        for i, (layer_id, layer_source) in enumerate(layer_sources.items()):
            progress.setValue(i)
            layer = QgsProject.instance().layerTreeRoot().findLayer(layer_id).layer()

            # Валидация загружаемого слоя по геометрии
            if self.dlg.checkBoxValidateGeom.isChecked():
                errors += self.validate_geom(layer)
     
            layer_fields = {
                i.name().lower(): {'qvariant': i.type(), 'typename': i.typeName()} 
                for i in layer.fields() 
                if i.name().lower() not in (self.feature_id_field, 'version_origin')
            } # поля слоя, сравниваемые с полями целевой таблицы
            # верхний регистр в названиях полей загр. данных переводится в нижний

            try:
                # целевая таблица регистрируется как слой
                wfs_layer = self.make_wfs_layer(
                    self.apgrLayersPrefix+layer_source['table_name'].split('.')[1])

                wfs_layer_fields = {
                    i.name().lower(): {'qvariant': i.type(), 'typename': i.typeName()} 
                    for i in wfs_layer.fields() 
                    if i.name() not in (self.feature_id_field, 'version_origin')
                } # сравниваемые поля целевой таблицы

                #Проверка NOT NULL полей
                if not self.generateDefaults:
                    errors += self.validate_notnull_fields(wfs_layer, layer)
                
                #Проверка типа геометрии
                errors += self.validate_geom_type(layer, wfs_layer)


                # Проверка справочных полей
                if self.dict_fields:
                    errors += self.validate_dict_fields(layer)

                # сравнение состава и типов полей
                for field_name in layer_fields:
                    try:
                        if not layer_fields[field_name]['qvariant'] == wfs_layer_fields[field_name]['qvariant']:
                            errors.append(
                                'Неверный тип поля {} у загружамого слоя {} - {}. Ожидаемый тип - {}'
                                .format(field_name, layer_id, layer_fields[field_name]['typename'], 
                                        wfs_layer_fields[field_name]['typename'])
                            )
                    except KeyError:
                        errors.append(
                            'В целевой таблице слоя {} отсутствует поле {}'.format(layer_id, field_name)
                        )
                if not self.initialUpload:
                    self.check_no_changes(layer, wfs_layer, self.apgrLayersPrefix[:-1] + '.' + layer_source['table_name'].split('.')[1])
            except Exception as e:
                errors.append('Ошибка при валидации слоя {}: {}'.format(layer.name(), str(e)))
        if not self.new_features and not self.initialUpload:
            errors += ["Отстуствуют слои с изменениями для создания минорной версии"]
        self.iface.mainWindow().blockSignals(False)
        self.iface.messageBar().popWidget(progressMessageBar)
        return errors

    def check_no_changes(self, layer, wfs_layer, table_name):
        wfs_layer_fields = [f.name() for f in wfs_layer.fields()]
        local_layer_fields = [f.name() for f in layer.fields()]
        new_local_features, old_feature_ids, deleted_feature_ids  = self.classify_features(
            layer, wfs_layer, wfs_layer_fields, local_layer_fields, table_name
        )
        if len(new_local_features) != 0 or len(deleted_feature_ids) != 0:
            self.new_features = True

    @staticmethod
    def validate_geom_type(local_layer, wfs_layer):
        """Сравнивает тип геометрии wfs и локального слоев"""
        geom_types = {
            0: 'Точка',
            1: 'Линия',
            2: 'Полигон',
            3: 'Неизвестно',
            4: 'None'
        }
        if not local_layer.geometryType() == wfs_layer.geometryType():
            return [
                'Тип геометрии слоя {} - {} не соответствует целевой таблице - {}'.format(
                    local_layer.name(),
                    geom_types[local_layer.geometryType()], 
                    geom_types[wfs_layer.geometryType()]
                )
            ]
        else:
            return []

    @staticmethod
    def translate_geos_msg(msg):
        translation = {
            'Nested shells': 'Вложенные внешние контуры (Nested shells)',
            'Self-intersection': 'Самопересечение (Self-intersection)',
            'Ring self-intersection': 'Самопересечение контура (Ring self-intersection)',
            'Hole lies outside shell': 'Вырез вне внешнего контура (Hole lies outside shell)',
            'Repeated point': 'Повторяющиеся точки (Repeated point)',
            'Nested holes': 'Вложенные вырезы (Nested holes)',
            'Duplicate rings':'Дублирование контуров (Duplicate rings)',
            'Too few points in geometry component': 'Недостаточное колличество точек (Too few points in geometry component)'
            # 'DisconnectedInterior': 'Нарушенная целостность внутреннего пространства',
            # 'InvalidCoordinate': 'Неверный формат координат',
            # 'RingNotClosed': 'Разомкнутый контур'
        } # Необходимо выяснить представления оставшихся исключений GEOS
        return translation.get(msg, msg)

    def read_notnull_fields(self, layer):
        """Возвращает список обязательных полей для данного слоя
        список формируется из полученного ответа на запрос DescribeFeatureType
        к WFS серверу
        """
        
        def find_complex_type(root):
            '''Возвращает элемент complexType'''
            for element in root:
                if 'complexType' in element.tag:
                    return element

        def find_sequence(element):
            '''Возвращает элемент sequence'''
            if 'sequence' in element.tag:
                return element
            return find_sequence(element[0])

        # Формируется запрос
        headers = self.nsi_interface.authManager.get_auth_headers()
        error = ''
        for i in range(int(self.config['wfsConnection']['max_upload_retries'])): #несколько попыток отправить запрос
            try:
                r = requests.get(
                    self.config['wfsConnection']['url'],
                    headers=headers,
                    params={
                        'service': 'wfs',
                        'version': '2.0.0',
                        'request': 'DescribeFeatureType',
                        'typeNames': self.config['wfsConnection']['workspace']+':'+layer.name()
                    }
                )
                # Парсинг xml ответа на запрос DescribeFeatureType
                root = ET.fromstring(r.text)
                ctype = find_complex_type(root)
                sequence = find_sequence(ctype)
                # Обязательные поля определяются по атрибуту nillable
                return [i.attrib['name'] for i in sequence if i.attrib['nillable']=='false']
            except Exception as e:
                error = str(e)
                print(error)

        raise Exception('Ошибка чтения ответа на запрос DescribeFeatureType: {}'.format(error))
    
    def validate_dict_fields(self, layer):
        """Валидация справочных полей слоя"""
        errors = [] #список ошибок
        if not layer.name() in self.dict_fields:
            return errors

        dict_vals = {}#справочные значения полей
        for field_name, dict_nick, dic_field, multiple in self.dict_fields[layer.name()]:
            dic_data = self.nsi_interface.get_field_dict_vals(dict_nick, dic_field)
            dict_vals[field_name] = {'values': dic_data[1], 'multiple': multiple}

        #проверка на соответствие атрибутов слоя справочным значениям
        for field, field_vals in dict_vals.items():
            for feature in layer.getFeatures():
                valid = True
                if field in [f.name() for f in feature.fields()]:
                    if feature[field] != NULL and feature[field] is not None and not isinstance(feature[field], str):
                        errors.append(
                            'Недопустимый тип справочного поля {} слоя {}: {}'.format(
                                field, layer.name(), 'Для справочных полей допустимы только строчные значения'
                            )
                        )
                        break

                    elif not field_vals['multiple']: #проверка поля с одиночным значением
                        valid, wrong_value = self.check_dic_vals(
                            feature[field], field_vals['values'], False
                        )
                    else: #проверка поля с множественными значениями
                        valid, wrong_value = self.check_dic_vals(
                            feature[field], field_vals['values'], True
                        )
                if not valid:
                    errors.append('Значение {} поля {} слоя {} не соответствует допустимым значениям {}'.format(
                        wrong_value, field, layer.name(), field_vals['values']
                    ))
     
        return errors

    @staticmethod
    def check_dic_vals(feature_field, field_vals, multiple):
        """Проверка значения поля со справочными"""
        if multiple: #если поле с множественными значениями, проверяются каждое индивидуально
            
            feature_field_vals = [i.strip() for i in feature_field.split(',')]
            for val in feature_field_vals:
                if val != '' and val not in field_vals:
                    return False, val

        elif feature_field != '' and feature_field not in field_vals:
            return  False, feature_field

        return True, None

    def validate_notnull_fields(self, source_layer, layer):
        """
        Проверяет загружаемые объекты на наличие null значений в not null полях
        """
        errors = [] # список ошибок
        error_msg = 'Недопустимое NULL значение в поле {}, слоя {}, объекта {}'
        # Определяются обязательные поля целевого слоя
        try:
            source_notnull_fields = self.read_notnull_fields(source_layer)
        except Exception as e:
            source_notnull_fields = []
            errors.append(
                'Не удалось определеить список обязательных полей для слоя {}: {}'.format(layer.name(), str(e))
            )

        layer_notnull_fields = [
            i.name() for i in layer.fields() 
            if i.name().lower() in source_notnull_fields
        ] # список полей слоя, на которые установлены ограничения формируется 
          # дополнительно из-за разного регистра полей в mid/mif и БД
        for feature in layer.getFeatures():
            for field in layer_notnull_fields:
                if feature[field] is None or feature[field] == NULL:
                    errors.append(error_msg.format(field, layer.name(), feature.id()))
                    # если поле с ограничением NOT NULL имеет NULL, добавляется ошибка
                    # break 
        
        return errors

    def validate_geom(self, layer):
        """Производит проверку геометрии объектов данного слоя.
        Возвращает список найденных ошибок"""
        errors = []
        error_prefix = 'Слой {} не прошел валидацию по геометрии: '.format(
            layer.name()
        )
        # проверка по охвату
        if not QgsRectangle(-70000, -70000, 70000, 70000).contains(layer.extent()):
            errors.append(
                error_prefix + \
                'объекты слоя за пределами допустимого охвата: ' + \
                '-70000, -70000, 70000, 70000'
            )
        if not self.get_project_geom().intersects(layer.extent()):
            errors.append(
                error_prefix + 'объекты слоя за пределами границ проекта'
            )

        # проверка по стандартному алгоритму проверки геом-ии qgis
        for feature in layer.getFeatures():
            if feature.geometry().isNull():
                errors.append(error_prefix + 'объект {} имеет нулевую геометрию'.format(str(feature.id())))
            validation_errors = list(feature.geometry().validateGeometry(1))
            if validation_errors:
                errors.append(
                    error_prefix + 'объект {} - '.format(str(feature.id())) + ', '.join(
                        map(self.translate_geos_msg, [e.what() for e in validation_errors])
                    )
                )
        return errors

    def confirm_upload(self):
        """Открывает диалоговое окно подтверждения загрузки"""
        # version_origin = self.version_origin if self.version_origin else '-'
        version_target = self.version_target if self.version_target else '-'

        confirmation = QMessageBox.question(
            self.iface.mainWindow(), 'Продолжить?',
            'Номер проекта: {}, целевая версия данных: {}'.format(
                self.oasi_number, version_target
            ),
            QMessageBox.Yes, QMessageBox.No
        )

        if confirmation == QMessageBox.No:
            return False
        return True

    def rollback(self):
        """Удаление записей добавленных в БД,
        включая информацию о загруженной версии и сами загруженные объекты
        """
        self.log('Отмена произведенных изменений...', 0)
        # удаление информации о версии
        self.delete_version()
        # удаление загруженных объектов
        # self.delete_features()

    def delete_version(self):
        """Формирует и отправляет запрос на удаление записей о версии,
        найденной по gid_change
        """
        self.apgr_versions_layer.startEditing()
        self.apgr_versions_layer.commitChanges() #Для обновления запроса
        # self.apgr_versions_layer.reload()
        request = QgsFeatureRequest().setFilterExpression(
            "gid_change = '{}'".format(self.gid_change)
        )
        self.apgr_versions_layer.startEditing()
        for version_feature in self.apgr_versions_layer.getFeatures(request):        
            self.apgr_versions_layer.deleteFeature(version_feature.id())

        self.apgr_versions_layer.commitChanges()

    def upload_layers(self, layer_sources, progress):
        """Загружает выбранные слои в базу данных,
        загружет информацию о версии данных в таблицу apgr_versions
        """
        #Открывается окно подтверждения загрузки
        if not self.confirm_upload():
            return
        #ID изменения (загрузки)
        self.gid_change = str(uuid4())

        self.log("Загрузка слоев в БД. {}: {}, gid_change: {}, oasi_documentid: {}, целевая версия: {}".format(
            'Первичная загрузка проекта' if self.initialUpload else 'Обновление данных проекта',
            self.oasi_number, self.gid_change, self.document_id, self.version_target),
            0, False, logFileName=self.logFileName)

        layers_uploaded = 0 #Счетчит загруженных слоев для отображения прогресса загрузки
        #Для каждого выбранного слоя осущ-ся загрузка согласно описанию в layer_sources
        layer_loaded = []
        for layer_id, layer_source in layer_sources.items():
            #Загружаемый слой определяется по id
            #Макс. колличество попыток указано в файле конф-ии (max_upload_retries)
            for i in range(int(self.config['wfsConnection']['max_upload_retries'])):
                layer = QgsProject.instance().layerTreeRoot().findLayer(layer_id).layer()
                success, error = self.upload_layer(layer, layer_source)
                if success:
                    if error is None:
                        layer_loaded.append(layer_source['table_name'])
                    break
                else: #Если возникла ошибка, повторная попытка с промежутком 1 сек.
                    self.log('Ошибка при загрузке слоя {}. Ошибка: {}. Повторная попытка № {}...'
                        .format(layer_id, error, str(i+1)), 1)
                    time.sleep(1)
                    
            if not success: # если возникла ошибка загрузки, выход
                self.errors.append("Ошибка {}: {}".format(str(len(self.errors) + 1), str(error)))
                raise Exception('Ошибка при загрузке объектов слоя {}: {}'.format(
                    layer.name(), error
                ))
            
            layers_uploaded += 1
            progress.setValue(layers_uploaded)

        self.log("Слои: {} успешно загружены в БД"
            .format(', '.join(layer_loaded)), 0)
        if self.errors:
            QMessageBox.critical(
                None, '', "Во время загрузки произошли ошибки, которые не удалось исправить:\n" + '\n'.join(self.errors)
            )
        else:
            QMessageBox.information(None, '', u"Загрузка данных прошла успешно.")
    
    def upload_layer(self, local_layer, layer_source):
        """Загружает слой в базу данных.
        Возвращает статус загрузки и сообщение об ошибке
        """
        # Целевая таблица регистрируется как временный слой
        wfs_layer_name = layer_source['table_name'].split('.')[1]
        wfs_layer = self.make_wfs_layer(self.apgrLayersPrefix+wfs_layer_name)
        self.log("Загрузка слоя: {}...".format(local_layer.name()), 0, False)
        try:
            old_feature_ids, new_feature_ids, deleted_feature_ids  = self.load_layer_features(wfs_layer_name, local_layer, wfs_layer)
            if old_feature_ids + new_feature_ids:
                if len(new_feature_ids) == 0 and len(deleted_feature_ids) == 0:
                    return True, "Отсутствуют изменения"
                success, msg = self.write_version(layer_source['gid_table'], old_feature_ids + new_feature_ids)
                if not success:
                    wfs_layer.startEditing()
                    for wfs_feature in wfs_layer.getFeatures():
                        if wfs_feature['gid_change'] == self.gid_change:
                            wfs_layer.deleteFeature(wfs_feature.id())
                    wfs_layer.commitChanges()
                    versions_table = self.make_wfs_layer(self.apgrLayersPrefix + 'apgr_versions')
                    version_number, subversion_number = map(int, self.version_target.split('.'))
                    versions_table.startEditing()
                    for version in versions_table.getFeatures():
                        if version['gid_table'] == layer_source['gid_table'] and \
                            version['version_number'] == version_number and \
                            version['subversion_number'] == subversion_number:
                            versions_table.deleteFeature(version.id())
                    versions_table.commitChanges()
                    raise Exception("Не удалось внести данные о версии: {}".format(msg))
            else:
                self.log("В слое: {} остутствуют объекты, попадающие в границы проекта".format(
                    local_layer.name()), 0, False, logFileName=self.logFileName)
                self.errors.append("Ошибка {}: в слое {} остутствуют объекты, попадающие в границы проекта".format(len(self.errors) + 1, str(local_layer.name())))

            self.uploaded_features[wfs_layer_name] = new_feature_ids
            # print(self.uploaded_features)
            self.log("Загрузка слоя: {} завершена. Загружено новых объектов: {}, удалено объектов: {}, объекты без изменений: {}"
                .format(local_layer.name(), len(new_feature_ids), len(deleted_feature_ids), len(old_feature_ids)),
                0, False, logFileName=self.logFileName
            )
        except Exception as e:
            return False, str(e)

        return True, None

    def load_layer_features(self, wfs_layer_name, local_layer, wfs_layer):
        """Загружает слой в БД. Возвращает списки:
        old_feature_ids - список id неизмененных объектов, 
        new_feature_ids - список id новых объектов
        """
        old_feature_ids, new_feature_ids = [], []

        # Если выбрана опция Сгенерировать значения по умолчанию, рачситываются layer_defaults значения
        if self.generateDefaults:
            layer_notnull_fileds = self.read_notnull_fields(wfs_layer)
            layer_defaults = self.source_field_defaults(local_layer, layer_notnull_fileds)
        else:
            layer_defaults = None

        layer_defaults = self.source_field_defaults(wfs_layer, layer_notnull_fileds=[])
        
        wfs_layer_fields = [f.name() for f in wfs_layer.fields()]
        local_layer_fields = [f.name() for f in local_layer.fields()]

        # Определяются загружаемые (измененные/новые) и незагружаемые( и неизмененные) объекты
        if self.initialUpload:
            new_local_features = list(local_layer.getFeatures())
            old_feature_ids = []
            deleted_feature_ids = []
        else:
            new_local_features, old_feature_ids, deleted_feature_ids = self.classify_features(
                local_layer, wfs_layer, wfs_layer_fields, local_layer_fields, self.apgrLayersPrefix[:-1] + '.' + wfs_layer_name
            )
        wfs_layer.startEditing()
        for local_feature in new_local_features:
            if self.get_project_geom().intersects(local_feature.geometry()):
                feature_added = self.insert_wfs_feature(
                    wfs_layer, local_feature, local_layer_fields, layer_defaults
                ) #объекты добавляются в слой wfs
        changes_commited = wfs_layer.commitChanges() #отправка транзакции
        if not changes_commited:
            error = wfs_layer.commitErrors()
            wfs_layer.startEditing()
            for wfs_feature in wfs_layer.getFeatures():
                if wfs_feature['gid_change'] == self.gid_change:
                    wfs_layer.deleteFeature(wfs_feature.id())
            wfs_layer.commitChanges()
            raise Exception('Не удалось загрузить объекты слоя {}: {}'
            .format(wfs_layer.name(), '\n'.join(map(str, error))))

        wfs_layer.reload()
        #поиск добавленных объектов в целевом слое по gid_change
        inserted_features_request = QgsFeatureRequest().setFilterExpression(
            "gid_change = '{}'".format(self.gid_change))
        new_feature_ids = [
            f[self.feature_id_field] for f in wfs_layer.getFeatures(inserted_features_request)
        ] #идентификаторы добавленных объектов
        for i in range(int(self.config['wfsConnection']['max_upload_retries'])):
            if len(new_feature_ids) == 0 and len(list(new_local_features)) != 0:
                time.sleep(1)
                self.log(u'Загруженные данные не обнаружены на geoserver-е. Попытка № {}'.format(str(i + 1)), 1)
                wfs_layer = self.make_wfs_layer(self.apgrLayersPrefix + wfs_layer_name)
                new_feature_ids = [
                    f[self.feature_id_field] for f in wfs_layer.getFeatures(inserted_features_request)]
            else:
                break
        local_layer.startEditing()
        if self.feature_id_field not in local_layer_fields: # Добавляем feature_id, если отсутствует
            local_layer.addAttribute(QgsField(self.feature_id_field, QVariant.Int))
            local_layer_fields.append(self.feature_id_field)
            local_layer.updateFields()
        if len(old_feature_ids) != 0:
            request = QgsFeatureRequest().setFilterExpression(
                '{} not in ({})'.format(self.feature_id_field, ','.join(map(str, old_feature_ids)))
            )  # выборка объектов целевого слоя по списку локальных feature_id
            features = list(local_layer.getFeatures(request))
        else:
            features = list(local_layer.getFeatures())
        wfs_features = list(wfs_layer.getFeatures(inserted_features_request))
        for local_feature in features:
            for wfs_feature in wfs_features:
                if self.features_simillar(local_feature, wfs_feature, wfs_layer_fields, local_layer_fields):
                    local_feature.setAttribute(self.feature_id_field, wfs_feature[self.feature_id_field])
                    local_layer.updateFeature(local_feature)
        local_layer.commitChanges()
        return old_feature_ids, new_feature_ids, deleted_feature_ids

    def classify_features(self, local_layer, wfs_layer, wfs_layer_fields, local_layer_fields, table_name):
        """Сравнивает загружаемые объекты с хранимыми в родительской версии и 
        классифицирует на новые (измененные) и неизмененные"""
        if not self.feature_id_field in [i.name() for i in local_layer.fields()]:
            #Если в слое отсутствует поле feature_id, все объекты считаются новыми
            return list(local_layer.getFeatures()), [], []

        #все feature_id объектов загружаемого слоя
        local_feature_ids = [
            f[self.feature_id_field] for f in local_layer.getFeatures()
        ]
        deleted_feature_ids = []
        wfs_features = self.get_wfs_features(wfs_layer, table_name, local_feature_ids)
        if len(wfs_features) == 0: #Если отсутсвтвую объекты для сравнения, то все объекты считаются новыми
            return list(local_layer.getFeatures()), [], []

        #список неидентичных локальных и удаленных объектов с идентичными feature_id
        new_local_features_ids = []
        for wfs_feature in wfs_features:
            local_request = QgsFeatureRequest().setFilterExpression(
                "{} = {}".format(self.feature_id_field, wfs_feature[self.feature_id_field])
            )
            try:
                local_feature = next(local_layer.getFeatures(local_request))#выбор локального объекта по feature_id
            except:
                deleted_feature_ids.append(wfs_feature[self.feature_id_field])
                continue
            wfs_layer.updateFeature(wfs_feature)
            if not self.features_simillar(local_feature, wfs_feature, wfs_layer_fields, local_layer_fields):
                new_local_features_ids.append(local_feature[self.feature_id_field])
                
        #выборка локальных новых и измененных объектов
        if len(new_local_features_ids) != 0:
            new_local_features_request = QgsFeatureRequest().setFilterExpression(
                "feature_id is NULL or feature_id = 0 or feature_id IN ({})"
                .format(','.join(map(str, new_local_features_ids)))
            )
            new_local_features = local_layer.getFeatures(new_local_features_request)
        else:
            new_local_features_request = QgsFeatureRequest().setFilterExpression(
                "feature_id is NULL or feature_id = 0"
            )
            new_local_features = local_layer.getFeatures(new_local_features_request)
        #feature_id неизмененных объектов
        old_feature_ids = [i for i in local_feature_ids if i not in new_local_features_ids and i not in deleted_feature_ids
                           and i != 0]
        return list(new_local_features), old_feature_ids, deleted_feature_ids

    def get_wfs_features(self, wfs_layer, table_name, local_feature_ids):
        table_guid_request = QgsFeatureRequest().setFilterExpression(
            "table_name='{}'".format(table_name)
        )
        table_feature = list(self.apgr_tables_layer.getFeatures(table_guid_request))[0]
        table_guid = table_feature['gid_table']
        versions_request = QgsFeatureRequest().setFilterExpression(
            "gid_table='{}'".format(table_guid)
        )
        versions = self.apgr_versions_layer.getFeatures(versions_request)
        feat_with_max_version = None
        max_version = 0
        max_subversion = 0
        for feature_id in local_feature_ids:
            for version in versions:
                # print(feature_id, version['feature_ids_string'].split(','))
                if str(feature_id) in version['feature_ids_string'].split(','):
                    if int(version['version_number']) > max_version:
                        feat_with_max_version = version
                        max_version = int(version['version_number'])
                        max_subversion = int(version['subversion_number'])
                    elif int(version['version_number']) == max_version and int(version['subversion_number']) > max_subversion:
                        feat_with_max_version = version
                        max_subversion = int(version['subversion_number'])
        feature_ids_string = feat_with_max_version['feature_ids_string']
        wfs_request = QgsFeatureRequest().setFilterExpression(
            '{} in ({})'.format(self.feature_id_field, feature_ids_string)
        )  # выборка объектов целевого слоя по списку локальных feature_id
        wfs_features = list(wfs_layer.getFeatures(wfs_request))
        return wfs_features

    def features_simillar(self, local_feature, wfs_feature, wfs_layer_fields, local_layer_fields):
        """Cравнивает данные объекты по атрибутам и геометрии.
        Если объекты отличаюстя, возвращает False, иначе True"""
        if wfs_feature is None:
            return False
        wfs_geom_multi = wfs_feature.geometry()
        wfs_geom_multi.convertToMultiType()
        local_geom_multi = local_feature.geometry()
        local_geom_multi.convertToMultiType()
        if not wfs_geom_multi.equals(local_geom_multi):
            return False
        for field in local_layer_fields:
            #верхний регистр в названиях полей загр. данных переводится в нижний
            if field.lower() in wfs_layer_fields:
                if field.lower() == 'feature_id' or (local_feature[field] == '' and wfs_feature[field.lower()] == 'N/A'):
                    continue
                if local_feature[field] != wfs_feature[field.lower()]:
                    return False
        return True
    
    def insert_wfs_feature(self, wfs_layer, feature, local_layer_fields, layer_defaults):
        """Создает новые объекты в WFS слое"""
        wfs_feature = QgsVectorLayerUtils.createFeature(wfs_layer)
        wfs_feature['gid_change'] = self.gid_change
        for attr in local_layer_fields:
            val = feature[attr]
            if attr not in (self.feature_id_field, 'version_origin'):
                if val == '' or val == NULL:
                    wfs_feature[attr.lower()] = layer_defaults.get(attr.lower())
                else:
                    wfs_feature[attr.lower()] = val
        wfs_feature.setGeometry(feature.geometry())
        success = wfs_layer.addFeature(wfs_feature)
        return success

    def delete_wfs_feature(self, wfs_layer, deleted_feature_id):
        wfs_request = QgsFeatureRequest().setFilterExpression(
            "{} = {}".format(self.feature_id_field, deleted_feature_id)
        )
        feature_for_delete = list(wfs_layer.getFeatures(wfs_request))[0]
        wfs_layer.deleteFeature(feature_for_delete.id())


    def write_version(self, gid_table, feature_ids):
        """Вносит информацию об объектах в таблицу версий"""
        versions_table = self.make_wfs_layer(self.apgrLayersPrefix+'apgr_versions')
        feature = QgsVectorLayerUtils.createFeature(versions_table)
        version_number, subversion_number = map(int, self.version_target.split('.'))

        feature['gid_change'] = self.gid_change
        feature['gid_table'] = gid_table
        feature['created_by'] = self.current_user()
        feature['oasi_documentid'] = self.document_id
        feature['version_number'] = version_number
        feature['subversion_number'] = subversion_number
        feature[self.version_feature_ids_field] = ','.join(map(str, feature_ids))
        
        versions_table.startEditing()
        versions_table.addFeature(feature)
        success = versions_table.commitChanges()
        return success, ','.join(versions_table.commitErrors())

    def source_field_defaults(self, layer, layer_notnull_fileds=[]):
        """Возвращает значения по-умолчанию для полей загружаемого слоя 
        согласно справочнику field_types_defaults
        """
        # Значения по-умолчанию формируются для обязательных полей целевой таблицы
        if layer_notnull_fileds: 
            layer_fields = {
                i.name().lower(): i.type() for i in layer.fields() 
                if i.name() not in (self.feature_id_field, 'version_origin') and \
                    i.name().lower() in layer_notnull_fileds
            }
        # Значения по-умолчанию формируются для всех полей загружаемого слоя
        else:
            layer_fields = {
                i.name().lower(): i.type() for i in layer.fields() 
                if i.name() not in (self.feature_id_field, 'version_origin')
            }

        defaults = {} # значения по-умолчанию для загружаемого слоя
        for f_name, f_type in layer_fields.items():
            for t_codes, t_default in self.field_types_defaults.items():
                if f_type in t_codes:
                    defaults[f_name] = t_default
                    break
        return defaults

    def get_target_version_number(self):
        """Расчет целевой версии данных"""

        feature_request = QgsFeatureRequest().setFilterExpression(
            "oasi_documentid='{}'".format(self.document_id)
        )
        version_records = self.apgr_versions_layer.getFeatures(feature_request)
        project_versions = sorted([(i['version_number'], i['subversion_number']) for i in version_records])

        max_version = project_versions[-1] if project_versions else (0, 0)
        if self.initialUpload:
            # при первичной загрузке увеличивается номер мастер-версии
            return '.'.join([str(max_version[0] + 1), '1'])
        else:
            # увеличивается номер подверсии
            return '.'.join([str(max_version[0]), str(max_version[1] + 1)])
