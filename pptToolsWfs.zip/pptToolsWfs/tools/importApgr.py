# -*- coding: utf-8 -*-

import os
import json
import time

from osgeo import ogr
from PyQt5 import QtWidgets
from psycopg2 import sql
from qgis.PyQt.QtWidgets import QProgressBar
from PyQt5.QtCore import QVariant
from qgis.core import QgsAuthMethodConfig, QgsApplication, QgsDataSourceUri, \
    QgsVectorLayer, QgsVectorFileWriter, QgsProject, QgsFeatureRequest, QgsExpressionContextUtils, \
    QgsLayerTreeGroup, QgsLayerTreeLayer, edit, QgsCoordinateReferenceSystem, Qgis, QgsField, \
    QgsDefaultValue, QgsFeature, QgsFields, NULL
from .baseTool import BaseTool

class ImportApgr(BaseTool):
    """Инструмент для импорта слоев из базы данных АПГР.
    Предполагаются два варианта использования: 1) загрузка определенной версии данных
    в рамка проекта ППТ, 2) загрузка шаблонов mid/mif.
    Пользователю предоставляется выбор таблиц для загрузки. Фильтр данных 
    в таблицах осуществляется по пространственному пересечению с полигоном 
    границы активного проекта ППТ. Осуществляется проверка загружаемых данных на
    соответствие атрибутам целевых таблиц и наличие ошибок в геометрии.
    Импортированные слои сохраняются в файлы и открываются в панели слоев QGIS.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dlg = kwargs['dialog']()
        self.dlg.pushButton.clicked.connect(self.select_directory)
        self.dlg.checkBoxLoadTemplates.toggled.connect(self.loadTemplatesToggled)
        self.dlg.comboBoxVersion.currentIndexChanged.connect(self.updateLayersChecklist)
        self.reset()
    
    def reset(self):
        """Сбрасывает значения атрибутов"""
        self.gid_change_index = -1
        self.document_id = ''
        self.selected_version = ''
        self.selected_subversion = ''
        self.downloadProject = not self.dlg.checkBoxLoadTemplates.isChecked()
        self.layers_info = {}
        self.read_meta_tables()

    def run(self):
        self.reset()
        self.document_id = self.get_document_id()

        if self.document_id == NULL:
            self.document_id = ''
        
        self.oasi_number = self.get_oasi_number()
        #Отображаемый номер документа ОАСИ
        self.dlg.labelOasiNumber.setText('-' if not self.oasi_number else str(self.oasi_number))
        #Список форматов сохраняемых файлов
        self.dlg.comboBoxFileFormat.clear()
        self.dlg.comboBoxFileFormat.addItems(
            ['tab', 'mif']
        )
        
        self.apgr_group = QgsProject.instance().layerTreeRoot().findGroup('Слои АПГР - mid/mif')
        if not self.apgr_group:
            self.apgr_group = QgsProject.instance().layerTreeRoot().addGroup('Слои АПГР - mid/mif')
            self.log("Создана группа слоев 'Слои АПГР - mid/mif'", 0, False)
        
        self.set_combobox_versions()
        
        self.dlg.show()
        result = self.dlg.exec_()
        if result:
            settings_valid = self.validate_settings()
            if not settings_valid: #выход при неверных параметрах
                return

            selected_layer_sources = {}
            # заполнение источников выбранных слоев
            for box in self.dlg.scrollArea.widget().findChildren(QtWidgets.QCheckBox):
                if box.checkState():
                    selected_layer_name = box.text().split('-')[0].strip()
                    selected_layer_sources[selected_layer_name] = self.layers_info[selected_layer_name]
            
            # директория сохранения файлов
            target_dir=self.dlg.directoryLineEdit.text()
            if self.downloadProject:
                target_dir=os.path.join(
                    target_dir,
                    self.oasi_number
                )

            self.load_wfs_layers(
                target_dir=target_dir, layer_sources=selected_layer_sources
            )
    
    def loadTemplatesToggled(self):
        """Действия при выборе/отмене опции Выгрузить шаблоны"""
        if self.dlg.checkBoxLoadTemplates.isChecked():
            # При выключенной опции Выгрузить шаблоны не отображаются элементы связанные 
            # с выбором версии проекта
            self.downloadProject = False
            self.dlg.labelAvailableVersions.hide()
            self.dlg.labelOasiNumber.hide()
            self.dlg.labelVersion.hide()
            self.dlg.comboBoxVersion.hide()
        else:
            self.downloadProject = True
            self.dlg.labelAvailableVersions.show()
            self.dlg.labelOasiNumber.show()
            self.dlg.labelVersion.show()
            self.dlg.comboBoxVersion.show()
        
        self.updateLayersChecklist()

    def select_directory(self):
        """Диалоговое окно выбора директории для загрузки слоев"""
        path = QtWidgets.QFileDialog.getExistingDirectory(
            None, 'Выберите папку сохранения файлов mid/mif'
        )
        self.dlg.directoryLineEdit.setText(path)
    
    def set_layers_checklist(self):
        """Заполняет виджет ScrollArea элементаами checkbox """
        layout = QtWidgets.QVBoxLayout()
        frame = QtWidgets.QFrame()
        group_title = ''
        for title, record in sorted(
            self.layers_info.items(),
            key=lambda kv: (
                kv[1]['group_name'],
                kv[0]
                )
            ):
            # Вставляет groupBox
            if group_title != record['group_name_ru']:
                group_title = record['group_name_ru']
                groupBox = QtWidgets.QGroupBox(group_title)
                groupBox.toggled.connect(self.group_box_checked)
                groupBox.setCheckable(True)
                groupBox.setChecked(False)
                groupBox_layout = QtWidgets.QVBoxLayout()
                groupBox.setLayout(groupBox_layout)
                layout.addWidget(groupBox)
            # Вставляет checkbox
            cb_title = title #Текст чекбокса
            if self.downloadProject:
                try: #Добавляется информация о версии слоев
                    cb_title += ' - Версия: ' + '.'.join(
                        [str(record['version_number']), str(record['subversion_number'])]
                    )
                except:
                    pass
            check_box = QtWidgets.QCheckBox(cb_title)
            font = check_box.font()
            font.setBold(False)
            check_box.setFont(font)
            groupBox_layout.addWidget(check_box)

        frame.setLayout(layout)
        self.dlg.scrollArea.setWidget(frame)

    def group_box_checked(self):
        """Действия при выборе группы слоев в списке доступных слоев"""
        for box in self.sender().findChildren(QtWidgets.QCheckBox):
            box.setChecked(self.sender().isChecked())
            box.setEnabled(True)

    def read_project_layers_info(self, version, subversion, oasi_documentid):
        """Формирует данные об источниках слоев"""
        
        request = QgsFeatureRequest().setFilterExpression(
            "oasi_documentid='{}' AND version_number <= {}"
            .format(self.document_id, version)
        )
        #Выбор всех версий проекта с индексом мастер-версии не выше запрашиваемой
        project_tables_all = {}
        for v in self.apgr_versions_layer.getFeatures(request):
            if not v['gid_table'] in project_tables_all:
                project_tables_all[v['gid_table']] = [(v['version_number'], v['subversion_number'])]
            else:
                project_tables_all[v['gid_table']].append((v['version_number'], v['subversion_number']))

        #Выбор максимальной версии для таблицы, которая не выше запрашиваемой версии
        project_tables_max = {}
        for table, versions in project_tables_all.items():
            for v in sorted(versions):
                if v[0] == int(version) and v[1] > int(subversion):#Если превышает запрашиваемую версию, выход
                    break
                project_tables_max[table] = v

        #Формирование словаря данных источников слоев проекта
        layers_info = {}
        for gid_table, v in project_tables_max.items():
            request = QgsFeatureRequest().setFilterExpression(
                "gid_table = '{}'".format(gid_table)
            )
            table_info = next(self.apgr_tables_layer.getFeatures(request))
            layers_info[table_info['mid_mif_name']] = {
                'table_name': table_info['table_name'],
                'group_name': table_info['group_name'],
                'group_name_ru': table_info['group_name_ru'],
                'gid_table': table_info['gid_table'],
                'version_number': v[0],
                'subversion_number': v[1]
            }

        return layers_info
    
    def read_versions(self, oasi_number=None):
        """Возвращает номера хранимых версий"""
        request = QgsFeatureRequest().setFilterExpression(
            "oasi_documentid='{}'".format(self.document_id)
        )
        versions = []
        for feature in self.apgr_versions_layer.getFeatures(request):
            versions.append(
                '.'.join(
                    [
                        str(feature['version_number']), str(feature['subversion_number'])
                    ]
                )
            )
        return sorted(list(set(versions)))
    
    def updateLayersChecklist(self):
        """Обновляет список доступных для выгрузки слоев"""
        try:
            self.selected_version, self.selected_subversion = \
                self.dlg.comboBoxVersion.currentText().split('.')
        except:
            self.selected_version, self.selected_subversion = None, None

        if self.downloadProject:
            self.layers_info = self.read_project_layers_info(
                self.selected_version, self.selected_subversion, self.document_id
            )
        else:
            self.layers_info = self.read_all_layers_info()

        self.set_layers_checklist()
    
    def set_combobox_versions(self):
        """Заполняет комбобокс доступными версиями данных проекта"""
        self.dlg.comboBoxVersion.clear()
        self.dlg.comboBoxVersion.addItem('')
        versions = self.read_versions(self.oasi_number)
        versions.sort(key=self.natural_keys, reverse=True)
        self.dlg.comboBoxVersion.addItems(
            versions
        )
    
    def validate_settings(self):
        """Проверка введенных параметров выгрузки"""
        if not self.document_id and self.downloadProject:
            self.log("Не удалось прочесть номер проекта. Необходимо настроиться на проект", 1)
            return False
        
        if not self.oasi_number and self.downloadProject:
            self.log("Не удалось установить номер первичной заявки ППТ", 1)
            return False

        try:
            if self.downloadProject:
                self.project_geom = self.get_project_geom()
            else:
                self.project_geom = None
        except:
            self.log("Не удалось прочесть геометрию проекта из слоя Первичные заявки ППТ. \
                Данные не будут сохранены", 1)
            return False
        
        if not self.dlg.directoryLineEdit.text():
            self.log('Не указан путь сохранения файлов', 1)
            return False
        
        return True

    def load_wfs_layers(self, target_dir, layer_sources):
        """
        1.Находит слои PostGis по указанному названию,
        2.Фильтрует данные по охвату проекта, 
        3.Загружает слои в указанную директорию
        4.Загружает сохраненные слои в проект QGIS
        """
        # Создание папки для сохранения загруженных слоев
        try:
            os.mkdir(target_dir)
        except FileExistsError:
            pass

        # Создается progress bar
        progressMessageBar, progress = self.make_progress_bar(
            len(layer_sources), "Выгрузка слоев из базы данных..."
        )
        self.iface.mainWindow().blockSignals(True)
        
        layers_downloaded = 0 #счетчик слоев для отобржения прогресса загрузки
        
        for title, layer_source in layer_sources.items():
            progress.setValue(layers_downloaded)
            try:
                for i in range(int(self.config['wfsConnection']['max_upload_retries'])):
                    success = self.load_wfs_layer(layer_source, title, target_dir)
                    if success:
                        break
                layers_downloaded += 1
            except Exception as e:
                self.log("Ошибка выгрузки слоя {}: {}".format(title, str(e)), 1)

        self.iface.mainWindow().blockSignals(False)
        self.iface.messageBar().popWidget(progressMessageBar)

        if not self.downloadProject:
            self.log("Создание шаблонов mid/mif завершено")
        
    def load_wfs_layer(self, layer_source, title, target_dir):
        """Сохранение данных WFS слоя в файл"""
        #название целевой группы формируется как имя группы + номер заявки ОАСИ
        group_name_ru = layer_source['group_name_ru']
        if self.downloadProject:
            group_name_ru += '-' + '.'.join(
                [str(self.selected_version), str(self.selected_subversion)]
            )
        else:
            group_name_ru += '_шаблоны'

        try:
            os.mkdir(
                os.path.join(target_dir, group_name_ru)
            )
        except FileExistsError:
            pass

        temp_layer = self.make_wfs_layer(
            self.apgrLayersPrefix+layer_source['table_name'].split('.')[1])

        save_file_format = self.dlg.comboBoxFileFormat.currentText()
        # Имя сохраняемого файла
        targe_file_name = os.path.join(
            target_dir,
            group_name_ru,
            title + '.' + save_file_format.lower()
        )
        # К полям временного слоя добавляется поле содержащее номер исходной версии
        fields = temp_layer.fields()
        if not self.downloadProject: #При выгрузке шаблонов, не сохраняется поле feature_id 
            fields.remove(fields.indexOf(self.feature_id_field))
        self.gid_change_index = fields.indexOf('gid_change')
        fields.remove(self.gid_change_index)
        # Сохранение в файл формата mid/mif
        file_writer = QgsVectorFileWriter(
            vectorFileName=targe_file_name, 
            fileEncoding='windows-1251', 
            fields=fields, 
            geometryType=temp_layer.wkbType(), 
            driverName='Mapinfo File',
            layerOptions=['BOUNDS=-60000,-60000,60000,60000'],
            datasourceOptions=['FORMAT={}'.format(save_file_format.upper())]
        )
        if self.downloadProject:
            result = self.create_features(
                temp_layer, fields, file_writer, 
                self.project_table_objects(
                    layer_source['gid_table'],
                    layer_source['version_number'],
                    layer_source['subversion_number'],
                )
            )
            if not result:
                return False

        del file_writer
        
        self.log('Обновляется информация и системе координат слоя {}'.format(title), 0, False)
        if save_file_format.lower() == 'mif':
            self.set_custom_crs(targe_file_name)#Добавление строки с информацией о системе координат

        self.log('Слой {} сохранен в файл {}'.format(title, targe_file_name), 0, False)

        if self.downloadProject:
            # Если производится загрузка данных проекта, созданный файл открывается в QGIS
            self.open_layer_file(title, targe_file_name, group_name_ru)
        return True
    
    def project_table_objects(self, gid_table, version_number, subversion_number):
        request = QgsFeatureRequest().setFilterExpression(
            "oasi_documentid='{}' AND gid_table='{}' AND version_number={} AND subversion_number={}"
            .format(self.document_id, gid_table, version_number, subversion_number)
        )
        version_record = next(self.apgr_versions_layer.getFeatures(request))

        return version_record[self.version_feature_ids_field]

    def create_features(self, layer, fields, file_writer, feature_ids):
        """Создает объекты выгружаемого слоя посредством
        интерфейса QgsVectorFileWriter
        """
        wfs_ids = ["{}".format(i) for i in feature_ids.split(',')]
        cql = "{} IN ({})".format(self.feature_id_field, ', '.join(wfs_ids))
        request = QgsFeatureRequest().setFilterExpression(cql)
        features = list(layer.getFeatures(request))
        if len(features) == 0:
            return False
        for f in features:
            new_feature = QgsFeature(fields)
            new_feature.setGeometry(f.geometry())
            attributes = f.attributes()
            attributes.pop(self.gid_change_index)
            # загружаемым объектам добавляется поле с номером версии
            new_feature.setAttributes(
                [attr if attr != NULL else None for attr in attributes]
            )

            file_writer.addFeature(new_feature)
        return True
    
    def open_layer_file(self, title, targe_file_name, group_name_ru):
        """Открывает созданный файл в QGIS"""
        new_layer = QgsVectorLayer(
            targe_file_name, title, 'ogr'
        )
        new_layer.setProviderEncoding('windows-1251')
        # для слоя устанавливается система координат
        crs = QgsCoordinateReferenceSystem('USER:100000')
        new_layer.setCrs(crs)
        QgsProject.instance().addMapLayer(new_layer, False)

        # Если отсутствует, создается группа слоев
        apgr_project_group = self.apgr_group.findGroup(self.oasi_number)
        if not apgr_project_group:
            apgr_project_group = self.apgr_group.addGroup(self.oasi_number)
            self.log('Создана группа слоев {}'.format(self.oasi_number), 0, False)

        apgr_project_subgroup = apgr_project_group.findGroup(group_name_ru)
        if not apgr_project_subgroup:
            apgr_project_subgroup = apgr_project_group.addGroup(group_name_ru)
            self.log('Создана группа слоев {}'.format(group_name_ru), 0, False)
        
        # слой сохраняется в группе
        apgr_project_subgroup.insertLayer(1, new_layer)
        # для слоя устанавливается система координат
        crs = QgsCoordinateReferenceSystem('USER:100000')
        new_layer.setCrs(crs)
        try:
            self.make_map_fields(self.read_dic_fields(), new_layer, self.nsi_interface)
        except Exception as e:
            self.log(
                'Не удалось определить справочные значения для формы редактирования слоя {}: {}'
                .format(title, str(e))
            )
        self.log('Слой {} добавлен к группе {}'.format(title, group_name_ru), 0, False)
            
    @staticmethod
    def set_custom_crs(file_name):
        """Добавляет строку с информацией о системе координат в файл .mif.
        Допустимо только при сохранении данных в формате mid/mif
        """
        # строка с информацией о СК в формате, соответствующем формату mif 
        crs_line = 'CoordSys Nonearth Units "m" Bounds (-60000,-60000) (60000,60000)\n'

        with open(file_name, 'r', encoding='windows-1251') as f:
            lines = f.readlines()
            lines.insert(3, crs_line) # вставляется строка с информацией о СК

        with open(file_name, 'w', encoding='windows-1251') as f:
            f.writelines(lines)

    